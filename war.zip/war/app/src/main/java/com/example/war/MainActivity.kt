package com.example.war

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap


// This is a class for decks of cards
class Deck() {
    companion object {
        // The cards of a full deck
        val cardsInFullDeck = arrayListOf("hearts2", "hearts3", "hearts4", "hearts5", "hearts6", "hearts7", "hearts8",
                "hearts9", "hearts10", "heartsjack", "heartsqueen", "heartsking", "heartsace",
                "spades2", "spades3", "spades4", "spades5", "spades6", "spades7", "spades8",
                "spades9", "spades10", "spadesjack", "spadesqueen", "spadesking", "spadesace",
                "clubs2", "clubs3", "clubs4", "clubs5", "clubs6", "clubs7", "clubs8",
                "clubs9", "clubs10", "clubsjack", "clubsqueen", "clubsking", "clubsace",
                "diamonds2", "diamonds3", "diamonds4", "diamonds5", "diamonds6", "diamonds7", "diamonds8",
                "diamonds9", "diamonds10", "diamondsjack", "diamondsqueen", "diamondsking", "diamondsace")

        // Return the rank of a given card
        fun getCardRank(card :String): Int {
            return ((Deck.cardsInFullDeck.indexOfFirst { it == card }) % 13)
        }
    }

    // An empty deck of cards
    var cards = ArrayList<String>()

    // Make the deck of cards empty
    fun emptyDeck() {
        this.cards = ArrayList<String>()
    }

    // Create a full deck of cards
    fun fullDeck() {
        this.customDeck(Deck.cardsInFullDeck)
    }

    // Choose what cards are in the deck
    fun customDeck(deckOfCards: ArrayList<String>) {
        this.emptyDeck()
        for (element in deckOfCards) {
            this.insertTopCard(element)
        }
    }

    // Put a card at the bottom of the deck
    private fun insertBottomCard(card :String) {
        this.cards.add(0, card)
    }

    // Put a card at the top of the deck
    fun insertTopCard(card :String) {
        this.cards.add(card)
    }

    // Put cards at the bottom of the deck
    fun insertCardsOnBottom(deckOfCards: ArrayList<String>) {
        if (deckOfCards.isNotEmpty()) {
            for (element in deckOfCards) {
                this.insertBottomCard(element)
            }
        }
    }

    // Put cards on the top of the deck
    fun insertCardsOnTop(deckOfCards: ArrayList<String>) {
        if (deckOfCards.isNotEmpty()) {
            for (element in deckOfCards){
                this.insertTopCard(element)
            }
        }
    }

    // Shuffle the deck of cards
    fun shuffleDeck() {
        this.cards.shuffle()
    }

    // Return the number of cards in the deck
    fun getSize(): Int {
        return this.cards.size
    }

    // Return the top card of the deck
    fun getTopCard(): String {
        return if (this.isEmpty()) "No Card"
        else this.cards[this.cards.size - 1]
    }

    // Return an array that contains the cards of the deck in order
    fun getDeck(): ArrayList<String> {
        return this.cards
    }

    // Check whether or not the deck of cards is empty
    fun isEmpty(): Boolean {
        return this.cards.size == 0
    }

    // Draw the top card
    fun draw() : String {
        val card = this.getTopCard()
        this.discardTopCard()
        return card
    }

    // Eliminate the top card of the deck
    private fun discardTopCard() {
        this.cards.removeLast()
    }
}

// Initialize variables
var numberOfTurns = 0
var createdOnce = false
var buttonText = "Next Turn"
var gameStatusText = ""
var gameInfo = HashMap<String, Any>()
var gameInfoList= ArrayList<HashMap<String, Any>>()

// Create the decks of the game
var mainDeck = Deck()
var player1Deck = Deck()
var player2Deck = Deck()
var player1CardsInPlay = Deck()
var player2CardsInPlay = Deck()

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize variables for the LinearLayouts that display cards
        val player1Box = findViewById<View>(R.id.player1Layout) as LinearLayout
        val player2Box = findViewById<View>(R.id.player2Layout) as LinearLayout

        // Only execute this code if the activity has not already been created
        if (!createdOnce) {
            // Store the current date as the start date of the new game
            val sdf = SimpleDateFormat("M/dd/yyyy")
            val currentDate = sdf.format(Date())
            gameInfo.put("date", currentDate)

            // Make the main deck a full deck and shuffle the deck
            mainDeck.fullDeck()
            mainDeck.shuffleDeck()

            // Give each player an equal number of cards from the deck
            while (!(mainDeck.isEmpty())) {
                player1Deck.insertTopCard(mainDeck.draw())
                player2Deck.insertTopCard(mainDeck.draw())
            }
        }

        // For both players, if the player has a card in play, display the top card that is in play
        if (!player1CardsInPlay.isEmpty()) {
            this.setImage(
                    player1CardsInPlay.getTopCard(),
                    player1Box
            )
        }
        if (!player2CardsInPlay.isEmpty()) {
            this.setImage(
                    player2CardsInPlay.getTopCard(),
                    player2Box
            )
        }

        // Allow the players to see the number of cards in each deck
        player1NumCards.text = "Number Of Cards: " + player1Deck.getSize().toString()
        player2NumCards.text = "Number Of Cards: " + player2Deck.getSize().toString()

        createdOnce = true // Mark that the activity has been created

        // Set the text of the game status TextView and the button
        nextTurn.text = buttonText
        gameStatus.text = gameStatusText
    }

    fun onNextTurnButtonClicked(view: View) {
        // Initialize variables for the LinearLayouts that display cards
        val player1Box = findViewById<View>(R.id.player1Layout) as LinearLayout
        val player2Box = findViewById<View>(R.id.player2Layout) as LinearLayout

        if (buttonText == "Next Turn") {
            // For each player, take a card from their main deck and put the card into play
            player1CardsInPlay.insertTopCard(player1Deck.draw())
            player2CardsInPlay.insertTopCard(player2Deck.draw())


            // Allow the players to see the number of cards in each deck
            player1NumCards.text = "Number Of Cards: " + player1Deck.getSize().toString()
            player2NumCards.text = "Number Of Cards: " + player2Deck.getSize().toString()

            // Change the text of the button to continue
            buttonText = "Continue"
            nextTurn.text = buttonText
        } else if (buttonText == "Continue") {
            // Add 1 to the number of turns
            numberOfTurns += 1

            // Find the rank of each player's card
            var rank1 = Deck.getCardRank(player1CardsInPlay.getTopCard())
            var rank2 = Deck.getCardRank(player2CardsInPlay.getTopCard())

            // Put the cards that are in play at the bottom of the player whose card has the highest
            // rank
            // Also empty the decks of the cards that are in play
            if (rank1 > rank2) {
                player1Deck.insertCardsOnBottom(player1CardsInPlay.getDeck())
                player1Deck.insertCardsOnBottom(player2CardsInPlay.getDeck())
                player1CardsInPlay.emptyDeck()
                player2CardsInPlay.emptyDeck()
            } else if (rank2 > rank1) {
                player2Deck.insertCardsOnBottom(player1CardsInPlay.getDeck())
                player2Deck.insertCardsOnBottom(player2CardsInPlay.getDeck())
                player1CardsInPlay.emptyDeck()
                player2CardsInPlay.emptyDeck()

            }

            // Shuffle the player's decks
            player1Deck.shuffleDeck()
            player2Deck.shuffleDeck()

            // Allow the players to see the number of cards in each deck
            player1NumCards.text = "Number Of Cards: " + player1Deck.getSize().toString()
            player2NumCards.text = "Number Of Cards: " + player2Deck.getSize().toString()

            // Check to see if the game has ended
            // If the game has ended, display and store the winner of the game
            if (player1Deck.getSize() == 52) {
                gameStatusText = "Player 1 Wins"
                buttonText = "Restart Game"
                gameInfo.put("winner", "player 1")
            } else if (player2Deck.getSize() == 52) {
                gameStatusText = "Player 2 Wins"
                buttonText = "Restart Game"
                gameInfo.put("winner", "player 2")
            } else if (player1Deck.isEmpty() && player2Deck.isEmpty()) {
                gameStatusText = "There Is A Tie"
                buttonText = "Restart Game"
                gameInfo.put("winner", "none")
            } else {
                // Change the text of the button to Next Turn
                buttonText = "Next Turn"
            }

            // Set the displayed text of the game status TextView and the button
            nextTurn.text = buttonText
            gameStatus.text = gameStatusText

            // If the previous turn was the last turn of the game, store the
            // number of turns of the game
            if (buttonText == "Restart Game") {
                gameInfo.put("number of turns", numberOfTurns)
                gameInfoList.add(gameInfo)
                gameInfo = HashMap<String, Any>()
            }
        } else { // Restart the game
            // Store the current date as the start date of the new game
            val sdf = SimpleDateFormat("M/dd/yyyy")
            val currentDate = sdf.format(Date())
            gameInfo.put("date", currentDate)

            // Reset the variables
            numberOfTurns = 0

            // Reset the decks of the game
            mainDeck = Deck()
            player1Deck = Deck()
            player2Deck = Deck()
            player1CardsInPlay = Deck()
            player2CardsInPlay = Deck()

            // Make the main deck a full deck and shuffle the deck
            mainDeck.fullDeck()
            mainDeck.shuffleDeck()

            // Give each player an equal number of cards from the deck
            while (!(mainDeck.isEmpty())) {
                player1Deck.insertTopCard(mainDeck.draw())
                player2Deck.insertTopCard(mainDeck.draw())
            }

            // Allow the players to see the number of cards in each deck
            player1NumCards.text = "Number Of Cards: " + player1Deck.getSize().toString()
            player2NumCards.text = "Number Of Cards: " + player2Deck.getSize().toString()

            // Do not show the status of the game
            gameStatusText = ""
            gameStatus.text = gameStatusText

            // Change the text of the button so that the new game can continue
            buttonText = "Next Turn"
            nextTurn.text = buttonText
        }

        // Remove the cards from the screen
        player1Box.removeAllViews()
        player2Box.removeAllViews()

        // For both players, if the player has a card in play, display
        // the top card that is in play
        if (!player1CardsInPlay.isEmpty()) {
            this.setImage(
                    player1CardsInPlay.getTopCard(),
                    player1Box
            )
        }
        if (!player2CardsInPlay.isEmpty()) {
            this.setImage(
                    player2CardsInPlay.getTopCard(),
                    player2Box
            )
        }
    }

    private fun setImage(card: String, layoutBox: LinearLayout) {
        val playerImage = ImageView(this) // Create an ImageView

        // Set the layout parameters of the ImageView to match the layout parameters of its parent
        playerImage.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT)

        // Set the ImageView to display the card
        when (card) {
            "clubs2" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs2
                    )
            )
            "clubs3" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs3
                    )
            )
            "clubs4" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs4
                    )
            )
            "clubs5" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs5
                    )
            )
            "clubs6" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs6
                    )
            )
            "clubs7" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs7
                    )
            )
            "clubs8" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs8
                    )
            )
            "clubs9" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs9
                    )
            )
            "clubs10" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubs10
                    )
            )
            "clubsjack" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubsjack
                    )
            )
            "clubsqueen" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubsqueen
                    )
            )
            "clubsking" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubsking
                    )
            )
            "clubsace" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.clubsace
                    )
            )
            "diamonds2" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds2
                    )
            )
            "diamonds3" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds3
                    )
            )
            "diamonds4" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds4
                    )
            )
            "diamonds5" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds5
                    )
            )
            "diamonds6" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds6
                    )
            )
            "diamonds7" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds7
                    )
            )
            "diamonds8" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds8
                    )
            )
            "diamonds9" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds9
                    )
            )
            "diamonds10" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamonds10
                    )
            )
            "diamondsjack" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamondsjack
                    )
            )
            "diamondsqueen" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamondsqueen
                    )
            )
            "diamondsking" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamondsking
                    )
            )
            "diamondsace" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.diamondsace
                    )
            )
            "hearts2" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts2
                    )
            )
            "hearts3" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts3
                    )
            )
            "hearts4" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts4
                    )
            )
            "hearts5" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts5
                    )
            )
            "hearts6" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts6
                    )
            )
            "hearts7" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts7
                    )
            )
            "hearts8" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts8
                    )
            )
            "hearts9" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts9
                    )
            )
            "hearts10" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.hearts10
                    )
            )
            "heartsjack" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.heartsjack
                    )
            )
            "heartsqueen" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.heartsqueen
                    )
            )
            "heartsking" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.heartsking
                    )
            )
            "heartsace" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.heartsace
                    )
            )
            "spades2" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades2
                    )
            )
            "spades3" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades3
                    )
            )
            "spades4" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades4
                    )
            )
            "spades5" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades5
                    )
            )
            "spades6" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades6
                    )
            )
            "spades7" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades7
                    )
            )
            "spades8" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades8
                    )
            )
            "spades9" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades9
                    )
            )
            "spades10" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spades10
                    )
            )
            "spadesjack" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spadesjack
                    )
            )
            "spadesqueen" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spadesqueen
                    )
            )
            "spadesking" -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spadesking
                    )
            )
            else -> playerImage.setImageDrawable(
                    ContextCompat.getDrawable(
                            applicationContext,
                            R.drawable.spadesace
                    )
            )
        }

        // Display the ImageView
        layoutBox.addView(playerImage)
    }

    fun onChangeActivityClicked(view: View) {
        // Create an intent to start the secondary activity
        val intent = Intent(this, MainActivity2::class.java)
        // Add information about the games that have been played to send to the activity
        intent.putExtra("gameInfoList",gameInfoList)
        // Start the activity
        startActivity(intent)
    }
}