package com.example.war

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main2.*
import java.util.ArrayList

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var game = 1 // Keep track of the current number of the game
        // Get information about games played from the first activity
        val gameInfoList: ArrayList<HashMap<String, Any>>? = intent.extras?.get("gameInfoList") as
                ArrayList<HashMap<String, Any>>?

        if (gameInfoList != null) { // Only execute if gameInfoList is not null
            // Display the information about every game played
            for (element in gameInfoList) {
                this.addText("Game $game", 50F)
                this.addText("date: " + element.get("date"), 25f)
                this.addText("winner: " + element.get("winner"), 25f)
                this.addText("number of turns: " + element.get("number of turns"), 25f)
                game += 1 // Increment to show the number of the next game
            }
        }
    }

    // textToAdd is the text that you want the TextView to display
    // textSize is the size of the text to be displayed
    fun addText(textToAdd: String, textSize: Float) {
        var text = TextView(this) // Create a TextView

        // Set the layout parameters of the TextView to match the layout parameters of its parent
        text.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT)
        text.text = textToAdd // Set the text to the text to be displayed
        text.textSize = textSize // Set the size of the text to the size of the text to be displayed
        text.gravity = Gravity.CENTER // Be sure that the text is centered
        infoLinearLayout.addView(text) // Add the text to the page
    }

    // Start the first activity
    fun onChangeActivityClicked2(view: View) {
        startActivity(Intent(this, MainActivity::class.java))
    }
}

